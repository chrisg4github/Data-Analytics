## Instructions

* Open [Stock_data_2016.xlsm](Stock_data_2016.xlsm)

* Click 'Enable Macros'

* Make sure that the stock are all included and filtered alphabetically

* Select the **Results** worksheet and delete everything under columns: Ticker, Total Change, % Change, Avg. Daily Change and Volume

* Change the color to no fill

* Delete everything under columns H and I

![Empty Results](../Resources/Results_empty.png)

* Click back to Stock_data_2016 tab.

* Run the Module called StockSolution

* **NOTE:** make sure you are on the Stock_data_2016 tab before running the VBA script.

![Module](../Resources/module.png)

* Results will appear on the Results sheet

![Solution](../Resources/Solution.png)
